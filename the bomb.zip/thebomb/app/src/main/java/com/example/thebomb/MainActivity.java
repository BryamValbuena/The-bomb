package com.example.thebomb;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button nextButton = findViewById(R.id.nextButton); // Suponiendo que tu botón tiene este id en tu XML
        nextButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                EditText editText = findViewById(R.id.editText); // Suponiendo que tu EditText tiene este id en tu XML
                String peliculaFavorita = editText.getText().toString();

                Intent intent = new Intent(MainActivity.this, panta2.class);
                intent.putExtra("peliculaFavorita", peliculaFavorita);
                startActivity(intent);
            }
        });
    }
}
