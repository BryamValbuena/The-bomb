package com.example.thebomb;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class panta2 extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_panta2);

        ImageButton backButton = findViewById(R.id.backButton);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish(); // Vuelve a la actividad anterior
            }
        });

        TextView textView = findViewById(R.id.textView); // Suponiendo que tu TextView tiene este id en tu XML
        Bundle extras = getIntent().getExtras();
        if (extras != null) {
            String peliculaFavorita = extras.getString("peliculaFavorita");
            textView.setText("Tu película favorita es: " + peliculaFavorita);
        }
    }
}
